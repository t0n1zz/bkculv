<img class="img-responsive" src="{{ asset('images/topnatal.png') }}" width="100%"
     style="vertical-align: top;margin-top: -30px;margin-bottom: -3%;"/>