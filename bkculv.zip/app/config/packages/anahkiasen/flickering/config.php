<?php return array(

	// API credentials
	//////////////////////////////////////////////////////////////////////

	'api_key'    => 'a9b66a1214ac857ef9c7fdf171a6dab5',
	'api_secret' => 'b17fa2767ab21b49',

	// Cache configuration
	//////////////////////////////////////////////////////////////////////

	'cache' => array(

		// Whether Flickering should cache requests or not
		'cache_requests' => false,

		// The lifetime of a cached request (minutes)
		'lifetime' => 60 * 24 * 365,
	),

);
