<?php return array(

	// OAuth paths
	//////////////////////////////////////////////////////////////////////

	'path'           => '/',
	'callback_url'   => '{path}flickr/oauth_callback',
	'oauth_callback' => '{path}',

	// Security salt
	//////////////////////////////////////////////////////////////////////

	'security_salt'  => 'LDFmiilYf8Fyw5W10rx4W1KsVrieQCnpBzzpTBWA5vJidQKDx8pMJbmw28R1C4m',

);
