<?php

class GambarKegiatan extends \Eloquent {
    
    protected $table = 'gambar_kegiatan';
    
    public static $rules = [];
    
    protected $fillable = [];
}